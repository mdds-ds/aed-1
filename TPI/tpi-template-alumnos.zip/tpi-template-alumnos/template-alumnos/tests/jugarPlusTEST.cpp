// Tests para la función jugarPlus.
// Ver el archovo README.md para ayuda

#include "../ejercicios.h"
#include "../auxiliares.h"
#include "gtest/gtest.h"

using namespace std;

// ┌───┬───┬───┬───┬───┐
// │ * │ * │ 2 │ * │ 1 │
// ├───┼───┼───┼───┼───┤
// │ 2 │ 2 │ 2 │ 1 │ 1 │
// ├───┼───┼───┼───┼───┤
// │ 0 │ 0 │ 0 │ 0 │ 0 │
// ├───┼───┼───┼───┼───┤
// │ 1 │ 2 │ 1 │ 1 │ 0 │
// ├───┼───┼───┼───┼───┤
// │ * │ 2 │ * │ 1 │ 0 │
// └───┴───┴───┴───┴───┘
tablero t_jugarPlus = {
        { cMINA,  cMINA,  cVACIA, cMINA, cVACIA },
        { cVACIA, cVACIA, cVACIA, cVACIA,  cVACIA },
        { cVACIA, cVACIA,  cVACIA, cVACIA, cVACIA },
        { cVACIA, cVACIA, cVACIA, cVACIA, cVACIA },
        { cMINA,  cVACIA, cMINA,  cVACIA, cVACIA },
};
jugadas j0_1 = {
        jugada(pos(0, 2), 2),jugada(pos(0, 4), 1),
};
jugadas j_1 = {
        jugada(pos(0, 2), 2),jugada(pos(0, 4), 1),
        jugada(pos(1,0),2),
        jugada(pos(2, 0), 0),jugada(pos(2, 1), 0),jugada(pos(2, 2), 0),jugada(pos(2, 3), 0),jugada(pos(2,4),0),
        jugada(pos(3, 4), 0),
        jugada(pos(4, 4), 0)
};
banderitas b = {
        pos(0,0), pos(0,1), pos(0,3),
        pos(4,0),pos(4,2)
};

TEST(jugarPlusTEST, noHayPosicionesSinMinasAdyacentesMarcadasComoBanderita){
    pos p = pos(1,0);
    jugarPlus(t_jugarPlus,b,p,j0_1);
    ASSERT_TRUE(mantieneJugadas(j0_1,j_1) && jugadasNoRepetidas(j_1) && incluyeJugadaActual(t_jugarPlus,j_1,p));
    ASSERT_TRUE(esPermutacionDeJugadas(j0_1,j_1));
}

banderitas b_1 = {
        pos(0,0), pos(0,1), pos(0,3),
        pos(2,3),
        pos(4,0),pos(4,2)
};
TEST(jugarPlusTEST, hayPosicionesSinMinasAdyacentesMarcadasComoBanderita){
    pos p = pos(1,0);
    jugarPlus(t_jugarPlus,b_1,p,j0_1);
    ASSERT_TRUE(mantieneJugadas(j0_1,j_1) && jugadasNoRepetidas(j_1) && incluyeJugadaActual(t_jugarPlus,j_1,p));
    ASSERT_FALSE(esPermutacionDeJugadas(j0_1,j_1));
}