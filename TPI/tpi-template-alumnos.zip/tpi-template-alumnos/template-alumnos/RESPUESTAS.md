﻿% Contesten aquí la pregunta sobre complejidad.

En el caso de la función jugarPlus, como la complejidad era del orden O(h*(n-1)!),
consideremos que h=n para facilitar el cálculo (ya que la longitud de jugadas
será más significativa que las banderitas, si es que estas existen). Por lo tanto quedará
una complejidad del orden O(n*(n-1)!) = O(n!).

En el caso de la función sugerirAutomatico121, si las jugadas fuesen una matriz 
conteniendo la cantidad de minas adyacentes en cada posición (i,k) (con las posiciones 
correspondiendo a las del tablero y con -1 si la posición no fue jugada), el tamaño de 
la estructura jugadas sería igual a n = t.size() (contiene las mismas posiciones que el 
tablero). Por lo tanto, por la forma en que está armada nuestra función sugerirAutomatico121 
la complejidad de peor caso O((g+m)*n^2), o bien para simplificar el cálculo O(m*n^2),
con g = b.size(), m = j.size() y n = t.size() pasaría a ser del orden O(n^3) puesto que 
ahora tendremos n = m.